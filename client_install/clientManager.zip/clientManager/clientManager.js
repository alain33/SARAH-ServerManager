/*
	Author: Stéphane Bascher
	Multiroom Server Manager client plugin
	
	Date: 15-03-2016
	Initial version: 1.0 
*/


// Global variables
var	Sarah
	, _clientConf
	, logger
	, socket
	, watcher
	, passOne
	, watchedList = []
	, cron
	, soxkilled = false
	, ss = require('socket.io-stream') 
	, fs = require('./node_modules/fs-extra')
	, _ = require('underscore')
	, path = require('./node_modules/path')
	, chokidar = require('chokidar')
	, cronJob = require('cron').CronJob
	, request = require('request')
	, restart = {server: false, client: false};

	 
// Init	module
exports.init = function(_SARAH){
	
	var winston = require('winston');
	logger = new (winston.Logger)({
		transports: [
			new (winston.transports.Console)()
		]
	});
	
	Sarah = getVersion(_SARAH);
	_clientConf = {
		client : getConfig().modules.clientManager.client || '',
		http : getConfig().modules.clientManager.http.serverManager.port || '',
		ip : getConfig().modules.clientManager.http.serverManager.ip || '',
		local_server_ip : getConfig().modules.clientManager.http.local.ip.server || '',
		local_client_ip : getConfig().modules.clientManager.http.local.ip.client || '',
		folders: getConfig().modules.clientManager.root.folders || '',
		watch : getConfig().modules.clientManager.root.watch || '',
		ignored: getConfig().modules.clientManager.root.deleteIgnored || '',
		watchInterval: getConfig().modules.clientManager.interval.watch || 700,
		streamInterval: getConfig().modules.clientManager.interval.stream || 900,
		restartClient: getConfig().modules.clientManager.restart.client || '',
		restartServer: getConfig().modules.clientManager.restart.server || '',
		sendType: getConfig().modules.clientManager.notification.sendType || '',
		soxpath: getConfig().modules.clientManager.intercom.sox || '',
		timerecord: getConfig().modules.clientManager.intercom.timeRecord  | 10
	};
	
	if (!_clientConf.client || !_clientConf.http || !_clientConf.ip) {
		logger.error('Config properties are not defined.');
		return;
	}
	
	initConnection();
	
}


// Sarah actions
exports.action = function(data, callback, config, SARAH){
	
	if (!_clientConf.client || !_clientConf.http || !_clientConf.ip) {
		logger.error('Config properties are not defined.');
		return callback({});
	}	
		
	// table of actions
	var tblActions = {
		closeSocket: function() { closeConnection(); },
		openSocket: function() { initConnection(function() { 
			Sarah.obj.speak("Client " + _clientConf.client + " connecté au serveur.");
		}); },
		intercom: function () { intercom(data.room || 'all')}
	};
	
	tblActions[data.command]();
	
	// return fucking callback
	callback({});
}


var closeConnection = function () {

	if (passOne) {
		logger.info("Connection with the Server Manager closed.");
		if (socket) socket.disconnect();
		if (socket) socket.close();
		socket = null;
		passOne = null;
		if (watcher) {
			watcher.close();
			watcher = null;
			watchedList = [];
		}
		Sarah.obj.speak("je me suis déconnecté du serveur.");
	} else
		Sarah.obj.speak("je ne suis pas connecté au serveur.");

}


var initConnection = function (callback) {
	
	var io = require('socket.io-client');
	socket = io.connect('http://' + _clientConf.ip + ':' + _clientConf.http, {autoConnect: true})
		.on('connect_error', function(err) {
			logger.error("Server Manager not started or closed : %s", err);
			if (socket) socket.disconnect();
			if (socket) socket.close();
			socket = null;
			if (watcher) {
				watcher.close();
				watcher = null;
				watchedList = [];
			}
			if (passOne) {
				passOne = null;
				var notify = require('./manager/' + _clientConf.sendType)({
					config: getConfig().modules.clientManager,
					Sarah: Sarah,
					logger: logger 
				});
				notify.send("Message du client " + _clientConf.client, "Le Server Manager s'est déconnecté.");
			}
			return;
		})
		.on('connect', function() {
			setSocket(callback);
		})
}



var setSocket = function (callback) {
	
	socket.emit('client_connect', _clientConf.client, _clientConf.local_server_ip, getConfig('http').port, _clientConf.local_client_ip, getConfig('http').remote.split(':')[2].replace('/',''));
	socket.on('connected', function() {
		logger.info("Connected to the Multiroom Server Manager.");
	});
	
	socket.on('remove_data', function(items, srvDir) {
		if (items.length > 0) {
			if (items[0].from == _clientConf.client || items[0].from == 'ALL') {
				items = changePath (items,srvDir);
				fs.remove(items[0].name, function (err) {
				  if (err) return logger.error('%s',err);
				  logger.info('%s deleted.', items[0].name);
				});
			} 
		}
	});
	
	socket.on('stop_watching', function(item, clt, dirItem) {
		var dir = __dirname + '/..';
				dir = path.normalize(__dirname + '/..')
					.replace(path.parse(dir)
					.root, path.sep)
					.split( path.sep)
					.join('/');
		
		var localitem = item.replace(dirItem, dir);
		watcher.unwatch(localitem);
		
		if (_clientConf.client == clt)
			setTimeout(function(){
				socket.emit('file_removed', item, clt, dir);
			}, 400);	
	});
	
	socket.on('receive_data', function(items,srvDir) {
		if (items.length > 0) {
			var srcItems = [];
			 _.map(items, function(item) { 
				srcItems.push({ name : item.name, from : item.from});
			});
			
			items = changePath (items,srvDir);
			receiveStream (socket,0,srcItems,items,receiveStream,function () { 
				if (restart.server || restart.client) {
					var tts;
					if (restart.server && restart.client) 
						tts = 'Je dois redémarrer, patiente 2 secondes s\'il te plait.';
					else if (restart.server) 
						tts = 'Je dois redémarrer le serveur, patiente 2 secondes s\'il te plait.';
					else if (restart.client) 
						tts = 'Je dois redémarrer le client, patiente 2 secondes s\'il te plait.';
					
					Sarah.obj.speak (tts, function() {
						setTimeout(function(){
							restartSarah();
							if (restart.server) return;
							restart = {server: false, client: false};
						}, 2000);
					});
				} 
				if (!passOne) {
					watchEvents(callback);
					passOne = true;
				}
			});
		} else {	
			if (!passOne) {
				watchEvents(callback);
				passOne = true;
			}
		}
			
	});
	
	ss(socket).on('send_file', function(item,stream) {
		logger.info("Send file to server");
		fs.createReadStream(item.name).pipe(stream);
	});
	
	ss(socket).on('send_intercom', function(item,stream) {
		logger.info("Send intercom file to server");
		fs.createReadStream(item).pipe(stream);
	});
	
	socket.on('receive_intercom', function(srcItem,srvDir,clientfrom) {
		var dir = path.normalize(__dirname)
				.replace(path.parse(__dirname)
				.root, path.sep)
				.split( path.sep)
				.join('/') + '/intercom';
		fs.ensureDirSync(dir);
		var item = dir + '/com-from-' + clientfrom + '.wav';
		receiveIntercom (socket,srcItem,item,clientfrom,function () { 
			Sarah.obj.play(item);
		});
	});
	
	socket.on('intercom_sent', function(tts) {
		Sarah.obj.speak(tts);
	})
	
	initscan();
	
}



var getConfig = function(value){

	var conf = (Sarah.version == 'V4') ? Config : Sarah.obj.ConfigManager.getConfig();
	if (value)
		 conf = conf[value];
	return conf;
}
	


var getVersion = function (_SARAH) {

	if (typeof Config === "undefined" ) {
		logger.info("Sarah version 3");
		return {version: 3, obj: _SARAH};
	} else  {
		logger.info("Sarah version 4");
		return {version: 4, obj: SARAH};
	}
	
}


var changePath = function (items,srvDir) {

	return _.map(items, function(item) { 
		var dir = path.normalize(__dirname + '/..')
				.replace(path.parse(__dirname + '/..')
				.root, path.sep)
				.split( path.sep)
				.join('/');

		item.name = item.name.replace(path.dirname(srvDir),path.dirname(dir));
		
		if (item.name.indexOf('/clients/'+_clientConf.client) != -1 ) 
			item.name = item.name.replace ('/clients/'+_clientConf.client, '')
		
		return item;
	});
}



var isToRestart = function (item, type) {
	
	//restart
	var itemPath = item.split('/'),
		restart = type.split(';'),
		flag = false,
		root = path.normalize(__dirname + '/../..')
			.replace(path.parse(__dirname + '/../..')
			.root, path.sep)
			.split( path.sep)
			.join('/');
	
	_.map(restart, function(file) { 
		file = root + '/' + file;
		
		var restartPaths = file.split('/'),
			maxPaths = restartPaths.length,
			pending = 0;
			
		if (!flag && maxPaths == itemPath.length) {
			var tested = _.map(restartPaths, function(pathfile) {
				var test;
				if (pending + 1 < maxPaths) {
					if (pathfile == '*')
						test = itemPath[pending];
					if (pathfile == itemPath[pending]) 
						test = pathfile;
				} else {
					if (pathfile.indexOf('*') != -1) {
						if (pathfile == '*.*') {
							test =  itemPath[pending];
						} else {
							if (pathfile.indexOf('*') == 0)
								test =  itemPath[pending].split('.')[0] + pathfile.split('*')[1];
							else
								test =  pathfile.split('*')[0] + itemPath[pending].split('.')[1];
						}
					} else
						test = pathfile;
				}
				++pending;
				return test;
			}).join('/');
			
			if (tested == item) flag = true;
		}
	});
	
	return flag;
	
}



var receiveIntercom = function (socket, srcItem, item, from, callback) {
	
	var stream = ss.createStream(); 
	ss(socket).emit('get_file', _clientConf.client, srcItem, stream); 
	logger.info("Receive file %s", item);
	stream.pipe(fs.createOutputStream(item));
	stream.on('data', function (data) {
		// Do nothing
	});
	
	stream.on('end', function (data) {
		callback();
	});
	
}


var receiveStream = function (socket,pos,srcItems,items,callback, callbackNext) {
	
	if (pos == items.length) return callbackNext();
	
	if ( items[pos].from == _clientConf.client || items[pos].from == 'ALL') {
		
		var timer = 0;
		if (passOne == true) {
			_.map(watchedList, function(file) { 
				if ( _.last(items[pos].name.split('/')) == file) {
					watcher.unwatch(items[pos].name);
					timer = _clientConf.streamInterval;	
				}
			});
		}
		
		if (!restart.server && isToRestart (items[pos].name, _clientConf.restartServer))
			restart.server = true;
		
		if (!restart.client && isToRestart (items[pos].name, _clientConf.restartClient))
			restart.client = true;
		
		setTimeout(function(){
			var stream = ss.createStream(); 
			ss(socket).emit('get_file', _clientConf.client, srcItems[pos].name, stream); 
			logger.info("Receive file %s", items[pos].name);
			stream.pipe(fs.createOutputStream( items[pos].name));
			stream.on('data', function (data) {
				// Do nothing
			});
			
			stream.on('end', function (data) {
				if (passOne == true) {
					_.map(watchedList, function(file) { 
						if ( _.last(items[pos].name.split('/')) == file)
							watcher.add(items[pos].name);
					});
				}
				callback(socket,++pos,srcItems,items,callback, callbackNext)
			});
		}, timer);
	} else
		callback(socket,++pos,srcItems,items,callback, callbackNext)
}



var initscan = function () {
	
	if (_clientConf.folders && _clientConf.folders.length > 0) {
		var items = [],
			watchFolders = _clientConf.folders.split(';'),
			pending = watchFolders.length,
			root = path.normalize(__dirname + '/../..')
					.replace(path.parse(__dirname + '/../..')
					.root, path.sep)
					.split( path.sep)
					.join('/');
		
		_.map(watchFolders, function(dir) { 
			dir = root + '/' + dir;
			fs.walk(dir)
			  .on('data', function (item) {
					if (item.stats.isFile())
						items.push({name : item.path.replace(path.parse(item.path)
															.root, path.sep)
															.split( path.sep)
															.join('/'), 
									size : item.stats.size, 
									create : item.stats.atime, 
									modify : item.stats.mtime.getTime()
						})
			  })
			  .on('end', function () {
				 if (!--pending)
					socket.emit('client_init', items, _clientConf.client, root);
			  }) 		
		});
	} else
		logger.info('No folder to watch');
}


var changeEvent = function (data, dir) {
	
	fs.stat(data, function(err, stats) {
		if (stats.isFile()) {
			var item = { name: data, size : stats.size, modify : stats.mtime.getTime() };
			socket.emit('file_changed', item, _clientConf.client, dir);
		}
	});
}


var removeEvent = function (data, dir) {
						
	socket.emit('unwatch', data, _clientConf.client, dir);
	
}


var watchEvents = function (callback) {

	var files = _clientConf.watch;
	if (files && files.length > 0 ) {
		var dir = __dirname + '/../..';
		dir = path.normalize(__dirname + '/../..')
			.replace(path.parse(dir)
			.root, path.sep)
			.split( path.sep)
			.join('/');
		var watchFiles = files.split(';')
		watchFiles = _.map(watchFiles, function(file) { 
					file = dir + '/' + file;
					return file;
				});
		
		// Initialize watcher.
		watcher = chokidar.watch(watchFiles, {
		  ignored: /[\/\\]\./,
		  persistent: true,
		  awaitWriteFinish : true,
		  interval: _clientConf.watchInterval,
		  alwaysStat: true
		});
		
		logger.info('Initial scan...')
		// Add event listeners.
		watcher
			.on('error', function(error){ logger.info("Watcher error: ", error)})
			.on('ready', function(){ 
										var watchedPaths = watcher.getWatched();
										_.map(watchedPaths, function(watchedFiles) { 
											_.map(watchedFiles, function(file) { 
												watchedList.push(file);
											});
										});
										
										addevents(callback)
									}); 
	} else
		logger.info('No files to watch');
} 


var addevents = function (callback) {
	
  watcher
		.on('change', function(path) { doevent('change', 'file', path)}) 
		.on('unlink', function(path) { doevent('unlink', 'file', path)})	
		
  logger.info('Initial scan complete. Ready for change.');
  if (callback) callback();
} 


var doevent = function (event, type, data) {
	
	var dir = path.normalize(__dirname + '/..')
			.replace(path.parse(__dirname + '/..')
			.root, path.sep)
			.split( path.sep)
			.join('/');
					
	data = data.split(path.sep)
						.join('/');			
	
	switch (event) {
	case 'change':
		// update file
		logger.info('%s updated.', data);
		changeEvent(data, dir);
		break;
	case 'unlink':
		// remove file
		var noevent = false,
			ignoredFiles = (_clientConf.ignored).split(';');
		if (ignoredFiles && ignoredFiles.length > 0) {
			_.map(ignoredFiles, function(file) { 
				if ( file.indexOf('*') != -1 && data.indexOf(file.replace('*','')) != -1) {
					noevent = true;
				} else {
					var folder = path.normalize(dir + '/..')
						.replace(path.parse(dir)
						.root, path.sep)
						.split( path.sep)
						.join('/');	
					if (folder + '/' + file == data) 
						noevent = true;
				}	
			}); 
		}
		
		if (!noevent) {
			logger.info('%s deleted.', data);
			removeEvent(data, dir);
		}
		break;
	}
	
}



var restartSarah = function() {
	
	var process;
	if (restart.server && restart.client)
		process = '%CD%/plugins/clientManager/bin/SARAH_Restart.vbs';
	else if (restart.server)
		process = '%CD%/plugins/clientManager/bin/SARAH_RestartServer.vbs';
	else if (restart.client)
		process = '%CD%/plugins/clientManager/bin/SARAH_RestartClient.vbs';
	
	var exec = require('child_process').exec;
	exec(process, function (error, stdout, stderr) {
			if (error) logger.error('restart Sarah: %s', error);
	});
	
}



var intercomEvent = function (data, dir, room) {
	
	fs.stat(data, function(err, stats) {
		if (stats.isFile() && stats.size > 0) 
			socket.emit('intercom', data, _clientConf.client, dir, room);
		else
			logger.error("Problem with the intercom file");
	});
}


var setcron = function () {
  
	if (cron) {
		logger.info('Previous cron stopped');
		cron.stop();
	}
	
	var d = new Date();
	var s = d.getSeconds() + _clientConf.timerecord;
	d.setSeconds(s);

	cron = new cronJob(d, function(done) {	
		logger.info('No message. Force listening to stop');
		soxkilled = true;
		var process = 'taskkill /T /F /IM sox.exe';
		var exec = require('child_process').exec;
		exec(process, function (error, stdout, stderr) {
			if (error) logger.error('Unable to kill sox: %s', error);
		});
	}, null, true);
	
}



var listen = function(value, callback) {

	if (Sarah.version == 'V3')
		var uri = getConfig('http').remote + '?listen=' + value;
	else
		var uri = getConfig('http').remote + "?context=" + ( value ? 'default': '');

	request(uri, function (error, response, body) {
		if (!error && response.statusCode != 200)
			logger.error ("Sarah Remote for listen: " + error);
		
		if (callback) callback();
	});
	
}

	
var intercom = function(room) {
	
	if (!_clientConf.soxpath) {
		logger.error("No configuration to listening");
		return;
	}
	
	setcron();
	
	listen (false, function () { 
		logger.info("Listening...");
		var dir = path.normalize(__dirname)
						.replace(path.parse(__dirname)
						.root, path.sep)
						.split( path.sep)
						.join('/') + '/intercom';
		fs.ensureDirSync(dir);
		
		var filepath = __dirname + '\\intercom\\com-record-' + _clientConf.client + '.wav',
			file = 'com-record-' + _clientConf.client + '.wav',
			process = _clientConf.soxpath + '\\sox -q -r 16000 -b 16 -t waveaudio 0 -t wav ' + filepath + ' silence 1 0.1 0.8% 1 1.0 0.8%',
			exec = require('child_process').exec;
		
		exec(process, function (error, stdout, stderr) {
			if ((error || stderr) && soxkilled == false)
				logger.error("sox error %s", error || stderr);
			else {
				if (soxkilled == false) {
					logger.info("Listening stopped");
					cron.stop();
					var data = dir + '/' + file;	
					setTimeout(function(){
						intercomEvent(data, dir, room);
					}, 1000);	
				} else
					soxkilled = false;
			} 
			listen (true);
		});
	});
	
}

